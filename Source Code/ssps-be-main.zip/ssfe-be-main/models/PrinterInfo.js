// models/PaperStore.js
const mongoose = require("mongoose");

const PrinterInfoSchema = new mongoose.Schema({
  printerID: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  brandName: {
    type: String,
    trim: true,
    default: "Unknown"
  },
  printerModel: {
    type: String,
    trim: true,
    default: "Unknown"
  },
  printerDesc: {
    type: String,
    trim: true,
    default: "None"
  },
  location: {
    type: String,
    trim: true,
    default: "Unknown"
  },
  printerStatus: {
    type: String,
    enum: ["On", "Off"],
    default: "On",
  },
});

module.exports = mongoose.model("PrinterInfo", PrinterInfoSchema);
