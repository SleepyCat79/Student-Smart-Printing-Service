// models/PaperStore.js
const mongoose = require("mongoose");

const PaperStoreSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
  },
  totalPapersRemaining: {
    type: Number,
    default: 0,
  },
  papersPurchased: {
    type: Number,
    default: 0,
  },
  papersUsed: {
    type: Number,
    default: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("PaperStore", PaperStoreSchema);
