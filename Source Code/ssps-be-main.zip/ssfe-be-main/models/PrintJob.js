// models/PrintJob.js
const mongoose = require("mongoose");

const PrintJobSchema = new mongoose.Schema({
  userEmail: {
    type: String,
    required: true,
    index: true,
  },
  name: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    required: true,
  },
  printer: {
    type: String,
    required: true,
  },
  paperSize: {
    type: String,
    required: true,
  },
  orientation: {
    type: String,
    required: true,
  },
  numofpapers: {
    type: Number,
    required: true,
    min: 1,
  },
  numbers: {
    type: Number,
    required: true,
    min: 1,
  },
  status: {
    type: String,
    enum: ["Success", "Error"],
    default: "Success",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("PrintJob", PrintJobSchema);
