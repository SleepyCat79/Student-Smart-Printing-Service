// models/RechargeHistory.js
const mongoose = require("mongoose");

const RechargeHistorySchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    lowercase: true,
    trim: true,
  },
  amount: {
    type: Number,
    required: true,
    min: 1,
  },
  paymentMethod: {
    type: String,
    enum: ["momo", "bank", "cash"],
    default: "momo",
  },
  status: {
    type: String,
    enum: ["Completed", "Pending"],
    default: "Completed",
  },
  date: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("RechargeHistory", RechargeHistorySchema);
