// routes/printJobs.js
const express = require("express");
const router = express.Router();
const PrintJob = require("../models/PrintJob");
const PaperStore = require("../models/PaperStore");
const mongoose = require("mongoose");

// Create a new print job
router.post("/", async (req, res) => {
  const {
    userEmail,
    name,
    type,
    printer,
    paperSize,
    orientation,
    numofpapers,
    numbers,
  } = req.body;

  if (
    !userEmail ||
    !name ||
    !type ||
    !printer ||
    !paperSize ||
    !orientation ||
    !numofpapers ||
    !numbers
  ) {
    return res.status(400).json({ error: "All fields are required." });
  }

  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    // Fetch the user's PaperStore
    const paperStore = await PaperStore.findOne({ email: userEmail }).session(
      session
    );

    if (
      !paperStore ||
      paperStore.totalPapersRemaining < numofpapers * numbers
    ) {
      // Tạo một PrintJob với status "Error"
      const errorPrintJob = new PrintJob({
        userEmail,
        name,
        type,
        printer,
        paperSize,
        orientation,
        numofpapers,
        numbers,
        status: "Error",
      });
      await errorPrintJob.save({ session });

      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ error: "Insufficient papers remaining." });
    }

    // Decrement the totalPapersRemaining
    paperStore.totalPapersRemaining -= numofpapers * numbers;

    // Increment the papersUsed
    paperStore.papersUsed += numofpapers * numbers;

    await paperStore.save({ session });

    // Tạo mới PrintJob với status "Success"
    const newPrintJob = new PrintJob({
      userEmail,
      name,
      type,
      printer,
      paperSize,
      orientation,
      numofpapers,
      numbers,
      status: "Success",
    });

    const savedJob = await newPrintJob.save({ session });

    await session.commitTransaction();
    session.endSession();

    res.status(201).json({ message: "Print job created.", printJob: savedJob });
  } catch (err) {
    await session.abortTransaction();
    session.endSession();
    console.error("Error creating print job:", err);

    // Tạo một PrintJob với status "Error"
    try {
      const errorPrintJob = new PrintJob({
        userEmail,
        name,
        type,
        printer,
        paperSize,
        orientation,
        numofpapers,
        numbers,
        status: "Error",
      });
      await errorPrintJob.save();
    } catch (saveErr) {
      console.error("Error logging failed print job:", saveErr);
    }

    res.status(500).json({ error: "Server error." });
  }
});

// Get all print jobs for a user
router.get("/all", async (req, res) => {
  try {
    const printJobs = await PrintJob.find({}).sort({
      createdAt: -1,
    });
    res.status(200).json(printJobs);
  } catch (err) {
    console.error("Error fetching print jobs:", err);
    res.status(500).json({ error: "Server error." });
  }
});

// Get all print jobs for a user
router.get("/:email", async (req, res) => {
  const userEmail = req.params.email;

  try {
    const printJobs = await PrintJob.find({ userEmail }).sort({
      createdAt: -1,
    });
    res.status(200).json(printJobs);
  } catch (err) {
    console.error("Error fetching print jobs:", err);
    res.status(500).json({ error: "Server error." });
  }
});

// Update a print job
router.put("/:id", async (req, res) => {
  const jobId = req.params.id;
  const updateData = req.body;

  try {
    const updatedJob = await PrintJob.findByIdAndUpdate(jobId, updateData, {
      new: true,
      runValidators: true,
    });

    if (!updatedJob) {
      return res.status(404).json({ error: "Print job not found." });
    }

    res
      .status(200)
      .json({ message: "Print job updated.", printJob: updatedJob });
  } catch (err) {
    console.error("Error updating print job:", err);
    res.status(500).json({ error: "Server error." });
  }
});

// Delete a print job
router.delete("/:id", async (req, res) => {
  const jobId = req.params.id;

  try {
    const deletedJob = await PrintJob.findByIdAndDelete(jobId);

    if (!deletedJob) {
      return res.status(404).json({ error: "Print job not found." });
    }

    res.status(200).json({ message: "Print job deleted." });
  } catch (err) {
    console.error("Error deleting print job:", err);
    res.status(500).json({ error: "Server error." });
  }
});

module.exports = router;
