// routes/printJobs.js
const express = require("express");
const router = express.Router();
const PrinterInfo = require("../models/PrinterInfo");
const mongoose = require("mongoose");

// Create a new printer
router.post("/", async (req, res) => {
  const {printerID, brandName, printerModel, printerDesc, location } = req.body;

  if (!printerID) {
    return res.status(400).json({ error: "All fields are required." });
  }

  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const newPrinter = new PrinterInfo({printerID,
    ...(brandName && { brandName }),
    ...(printerModel && { printerModel }),
    ...(printerDesc && { printerDesc }),
    location});
    const savedPrinter = await newPrinter.save({ session });

    await session.commitTransaction();
    session.endSession();

    res.status(201).json({ PrinterInfo: savedPrinter });
  } catch (err) {
    await session.abortTransaction();
    session.endSession();
    console.error("Error creating print job:", err);
    res.status(500).json({ error: "Lỗi máy in bị trùng lặp" });
  }
});

// Get all printer info for a user
router.get("/all", async (req, res) => {
  try {
    const printerInfos = await PrinterInfo.find({}).sort({
      printerID: -1,
    });
    res.status(200).json(printerInfos);
  } catch (err) {
    console.error("Error fetching print jobs:", err);
    res.status(500).json({ error: "Server error." });
  }
});

//Update printer status
router.patch("/:id/status", async (req, res) => {
  const id = req.params.id;
  const { printerStatus } = req.body;

  if (!["Off", "On"].includes(printerStatus)) {
    return res.status(400).json({ error: "Invalid status value." });
  }

  try {
    const updatedPrinter = await PrinterInfo.findByIdAndUpdate(id,{printerStatus},{ new: true });

    if (!updatedPrinter) {
      return res.status(404).json({ error: "Printer not found." });
    }
    res.status(200).json(updatedPrinter);
  } catch (err) {
    console.error("Error updating status:", err);
    res.status(500).json({ error: "Server error." });
  }
});

module.exports = router;
