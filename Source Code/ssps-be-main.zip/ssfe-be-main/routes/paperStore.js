// routes/paperStore.js
const express = require("express");
const router = express.Router();
const PaperStore = require("../models/PaperStore");
const RechargeHistory = require("../models/RechargeHistory");

// @route   POST /api/paperStore/recharge
// @desc    Recharge papers for a user
// @access  Public (Adjust as needed)
router.post("/recharge", async (req, res) => {
  const { email, rechargeAmount, paymentMethod } = req.body;

  // Validate input
  if (!email || !rechargeAmount) {
    return res
      .status(400)
      .json({ message: "Email and rechargeAmount are required." });
  }

  if (typeof rechargeAmount !== "number" || rechargeAmount <= 0) {
    return res
      .status(400)
      .json({ message: "Recharge amount must be a positive number." });
  }

  if (
    paymentMethod &&
    !["momo", "bank", "cash"].includes(paymentMethod.toLowerCase())
  ) {
    return res.status(400).json({
      message: "Invalid payment method. Allowed: momo, bank, cash.",
    });
  }

  try {
    // Find the PaperStore document by email
    let paperStore = await PaperStore.findOne({
      email: email.toLowerCase().trim(),
    });

    // If not found, create a new PaperStore with zeros
    if (!paperStore) {
      paperStore = new PaperStore({
        email,
        totalPapersRemaining: 0,
        papersPurchased: 0,
        papersUsed: 0,
      });
    }

    // Update the PaperStore
    paperStore.papersPurchased += rechargeAmount;
    paperStore.totalPapersRemaining += rechargeAmount;

    // Save the PaperStore document
    await paperStore.save();

    // Create a new recharge history entry
    const rechargeHistory = new RechargeHistory({
      email: email.toLowerCase().trim(),
      amount: rechargeAmount,
      paymentMethod: paymentMethod || "momo",
      status: "Completed", // Or determine based on payment method if needed
    });

    // Save the recharge history
    await rechargeHistory.save();

    return res.status(200).json({
      message: "Papers recharged successfully.",
      paperStore: {
        email: paperStore.email,
        totalPapersRemaining: paperStore.totalPapersRemaining,
        papersPurchased: paperStore.papersPurchased,
        papersUsed: paperStore.papersUsed,
        createdAt: paperStore.createdAt,
      },
      rechargeHistory: {
        id: rechargeHistory._id,
        date: rechargeHistory.date,
        amount: rechargeHistory.amount,
        paymentMethod: rechargeHistory.paymentMethod,
        status: rechargeHistory.status,
      },
    });
  } catch (error) {
    console.error("Error recharging papers:", error);
    return res.status(500).json({ message: "Server error." });
  }
});

// @route   GET /api/paperStore/papers/:email
// @desc    Get paper details for a user
// @access  Public (Adjust as needed)
router.get("/papers/:email", async (req, res) => {
  const { email } = req.params;

  if (!email) {
    return res.status(400).json({ message: "Email is required." });
  }

  try {
    let paperStore = await PaperStore.findOne({
      email: email.toLowerCase().trim(),
    });

    // If not found, create a new PaperStore with zeros
    if (!paperStore) {
      paperStore = new PaperStore({
        email,
        totalPapersRemaining: 0,
        papersPurchased: 0,
        papersUsed: 0,
      });
      await paperStore.save();
    }

    return res.status(200).json({
      paperStore: {
        email: paperStore.email,
        totalPapersRemaining: paperStore.totalPapersRemaining,
        papersPurchased: paperStore.papersPurchased,
        papersUsed: paperStore.papersUsed,
        createdAt: paperStore.createdAt,
      },
    });
  } catch (error) {
    console.error("Error fetching paper details:", error);
    return res.status(500).json({ message: "Server error." });
  }
});

// @route   GET /api/paperStore/rechargeHistory/:email
// @desc    Get recharge history for a user
// @access  Public (Adjust as needed)
router.get("/rechargeHistory/:email", async (req, res) => {
  const { email } = req.params;

  if (!email) {
    return res.status(400).json({ message: "Email is required." });
  }

  try {
    const history = await RechargeHistory.find({
      email: email.toLowerCase().trim(),
    })
      .sort({ date: -1 }) // Sort by date descending
      .lean(); // Get plain JavaScript objects

    const formattedHistory = history.map((entry) => ({
      id: entry._id,
      date: entry.date,
      amount: entry.amount,
      paymentMethod: entry.paymentMethod,
      status: entry.status,
    }));

    return res.status(200).json({
      history: formattedHistory,
    });
  } catch (error) {
    console.error("Error fetching recharge history:", error);
    return res.status(500).json({ message: "Server error." });
  }
});

module.exports = router;
