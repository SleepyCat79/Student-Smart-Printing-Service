// File: Sidebar.jsx
import React, { useContext } from "react";
import { Link, useLocation } from "react-router-dom";
import * as Fa from "react-icons/fa";
import * as Ai from "react-icons/ai";

import { AuthContext } from "../AuthContext/AuthContext";

const Sidebar = () => {
  const { logout } = useContext(AuthContext);
  const location = useLocation(); // Get the current location

  return (
    <div className="w-1/6  bg-customCyan text-white flex flex-col round-xl">
      <div className="flex items-center h-16 m-10 ">
        <img className="w-28 h-24" src="/logo.png" alt="" />
        <span className="text-3xl font-bold">SSPS</span>
      </div>

      <nav className="flex-1 px-2 py-4 space-y-6">
        <Link
          to="/"
          className={`flex items-center px-4 py-2 rounded ${
            location.pathname === "/"
              ? "bg-white text-customCyan font-bold"
              : "hover:bg-white hover:text-customCyan"
          }`}
        >
          <Fa.FaHome className="mr-2 text-md" />
          <span className="ml-10">Dashboard</span>
        </Link>

        <Link
          to="/print"
          className={`flex items-center px-4 py-2 rounded ${
            location.pathname === "/print"
              ? "bg-white text-customCyan font-bold"
              : "hover:bg-white hover:text-customCyan"
          }`}
        >
          <Ai.AiFillPrinter className="mr-2 text-md" />
          <span className="ml-10">Đặt in</span>
        </Link>
        <Link
          to="/history"
          className={`flex items-center px-4 py-2 rounded ${
            location.pathname === "/history"
              ? "bg-white text-customCyan font-bold"
              : "hover:bg-white hover:text-customCyan"
          }`}
        >
          <Fa.FaFileAlt className="mr-2 text-md" />
          <span className="ml-10">Lịch sử in</span>
        </Link>
        <Link
          to="/recharge"
          className={`flex items-center px-4 py-2  rounded ${
            location.pathname === "/recharge"
              ? "bg-white text-customCyan font-bold"
              : "hover:bg-white hover:text-customCyan"
          }`}
        >
          <Fa.FaMoneyCheckAlt className="mr-2 text-md" />
          <span className="ml-10">Nạp giấy</span>
        </Link>
      </nav>

      {/* Footer */}
      <div className="px-4 py-2 bg-customBlue">
        <button
          onClick={logout} // Call the logout function on click
          className="w-full flex items-center px-4 py-2 hover:bg-white hover:text-customCyan font-bold rounded"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
