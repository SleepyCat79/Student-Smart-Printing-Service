// File: Taskbar.jsx
import React, { useContext, useState, useEffect } from "react";
import * as FA from "react-icons/fa";
import { AuthContext } from "../AuthContext/AuthContext";

const Taskbar = ({ TypeTask, ShowSearch, TextDisplay }) => {
  const { user } = useContext(AuthContext);
  const [paperData, setPaperData] = useState({
    totalPapersRemaining: 0,
    papersPurchased: 0,
    papersUsed: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Fetch paper data when component mounts or user changes
  useEffect(() => {
    const fetchPaperData = async () => {
      if (!user || !user.email) {
        setError("User is not authenticated.");
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(
          `https://ssfe-be.vercel.app/api/paperStore/papers/${encodeURIComponent(
            user.email
          )}`
        );

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to fetch paper data.");
        }

        const data = await response.json();
        setPaperData(data.paperStore);
      } catch (err) {
        console.error("Error fetching paper data:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPaperData();
  }, [user]);

  return (
    <div className="flex items-center justify-between p-4">
      <div className="flex items-center space-x-4">
        <span className="text-black font-bold text-2xl">{TextDisplay}</span>
      </div>

      <div className="flex items-center space-x-6">
        {/* Paper Count */}
        <div className="flex items-center space-x-2">
          {loading ? (
            <p className="text-xs font-medium">Loading...</p>
          ) : error ? (
            <p className="text-xs font-medium text-red-500">Error</p>
          ) : (
            <>
              <p className="text-xs font-medium">
                {paperData.totalPapersRemaining}
              </p>
              <FA.FaRegNewspaper className="text-xl text-blue-500" />
            </>
          )}
        </div>

        {/* Notifications Icon */}
        <FA.FaBell className="text-xl text-blue-500" />

        {/* User Info */}
        <div className="flex items-center space-x-2">
          <img
            className="h-10 w-10 rounded-full"
            src="./vua truong.jpg" // Ensure you have a default avatar
            alt="User Avatar"
          />
          <p className="text-sm text-gray-600">{user.email}</p>
        </div>
      </div>
    </div>
  );
};

export default Taskbar;
