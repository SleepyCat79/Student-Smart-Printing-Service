import React, { useContext, useEffect, useState } from "react";
import { Route, Routes, Navigate, useLocation } from "react-router-dom";
import { AuthContext } from "./AuthContext/AuthContext";
import Sidebar from "./components/Sidebar";
import Taskbar from "./components/Taskbar";
import SignIn from "./screens/SignIn/SignIn";
import PrintScreen from "./screens/PrintScreen/PrintScreen";
import Home from "./screens/Homepage/Homepage";
import Recharge from "./screens/Recharge/Recharge";
import History from "./screens/History/History";
import AdminPage from "./screens/Homepage/AdminPage";
import AdminSidebar from "./components/AdminSidebar";
import ManagePrinter from "./screens/ManagePrinter/ManagePrinter";
import AdminHistory from "./screens/History/AdminHistory";

const PrivateRoute = ({ children }) => {
  const { user } = useContext(AuthContext);
  return user ? children : <Navigate to="/signin" replace />;
};

const App = () => {
  const { user } = useContext(AuthContext);
  const location = useLocation();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const checkAdminStatus = async () => {
      if (user) {
        try {
          console.log("Checking admin status for user:", user.email); // Add logging
          const response = await fetch(
            "https://ssfe-be.vercel.app/api/checkAdmin",
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ email: user.email }),
            }
          );
          const data = await response.json();
          console.log("Admin status response:", data); // Add logging
          setIsAdmin(data.isAdmin);
        } catch (error) {
          console.error("Error checking admin status:", error);
        }
      }
    };

    checkAdminStatus();
  }, [user]);

  const getTaskbarProps = () => {
    switch (location.pathname) {
      case "/":
        return {
          TypeTask: "Home",
          ShowSearch: false,
          TextDisplay: "Tổng quan",
        };
      case "/dashboard":
        return {
          TypeTask: "Dashboard",
          ShowSearch: false,
          TextDisplay: "Tổng quan",
        };
      case "/print":
        return {
          TypeTask: "Settings",
          ShowSearch: false,
          TextDisplay: "Đặt in thông minh",
        };
      case "/history":
        return {
          TypeTask: "Profile",
          ShowSearch: false,
          TextDisplay: "Lịch sử in ấn",
        };
      default:
        return {
          TypeTask: "Default",
          ShowSearch: false,
          TextDisplay: "Nạp giấy vào tài khoản",
        };
    }
  };

  const taskbarProps = getTaskbarProps();

  return (
    <div className="flex h-screen">
      {user && (isAdmin ? <AdminSidebar /> : <Sidebar />)}
      <div
        className={`flex-1 flex flex-col ${
          user ? "" : "justify-center items-center"
        }`}
      >
        {user && <Taskbar {...taskbarProps} />}
        <div className={`overflow-hidden ${user ? "" : "w-full"}`}>
          <Routes>
            <Route
              path="/signin"
              element={!user ? <SignIn /> : <Navigate to="/" replace />}
            />
            <Route
              path="/"
              element={
                <PrivateRoute>
                  {isAdmin ? <AdminPage /> : <Home />}
                </PrivateRoute>
              }
            />
            <Route
              path="/managePrinter"
              element={
                <PrivateRoute>
                  <ManagePrinter />
                </PrivateRoute>
              }
            />
            <Route
              path="/adminHistory"
              element={
                <PrivateRoute>
                  <AdminHistory />
                </PrivateRoute>
              }
            />
            <Route
              path="/print"
              element={
                <PrivateRoute>
                  <PrintScreen />
                </PrivateRoute>
              }
            />
            <Route
              path="/recharge"
              element={
                <PrivateRoute>
                  <Recharge />
                </PrivateRoute>
              }
            />
            <Route
              path="/history"
              element={
                <PrivateRoute>
                  <History />
                </PrivateRoute>
              }
            />
            <Route
              path="*"
              element={
                user ? (
                  <Navigate to="/" replace />
                ) : (
                  <Navigate to="/signin" replace />
                )
              }
            />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default App;
