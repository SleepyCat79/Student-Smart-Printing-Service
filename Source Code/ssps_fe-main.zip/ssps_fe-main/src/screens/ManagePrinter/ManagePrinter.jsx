import React, { useState, useEffect, useContext } from "react";
//import * as FA from "react-icons/fa";
import { AuthContext } from "../../AuthContext/AuthContext";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ManagePrinter = () => {
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [printerID, setPrinterID] = useState("");
  const [brandName, setBrandName] = useState("");
  const [printerModel, setPrinterModel] = useState("");
  const [printerDesc, setPrinterDesc] = useState("");
  const [location, setLocation] = useState("");
  const [printerList, setPrinterList] = useState([]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await fetch(
        "https://ssfe-be.vercel.app/api/printerInfo",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            printerID,
            brandName,
            printerModel,
            printerDesc,
            location,
          }),
        }
      );

      if (response.ok) {
        toast.success("Máy in đã được thêm thành công!");
        const data = await response.json();
        setPrinterList([data.PrinterInfo, ...printerList]);
      } else {
        throw new Error("Failed to add printers.");
      }
    } catch (err) {
      console.error("Network error:", err);
      toast.error("Lỗi mạng.");
    }
    setPrinterID("");
    setLocation("");
    setBrandName("");
    setPrinterModel("");
    setPrinterDesc("");
    setShowModal(false);
  };
  const updateStatus = async (event) => {
    try {
      const response = await fetch(
        `https://ssfe-be.vercel.app/api/printerInfo/${event.target.id}/status`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            printerStatus: event.target.innerText === "Khả dụng" ? "Off" : "On",
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        toast.error("Error updating printer status:", errorData.error);
        return;
      }

      const updatedPrinter = await response.json();
      setPrinterList((prev) =>
        prev.map((printer) =>
          printer._id === event.target.id ? updatedPrinter : printer
        )
      );
    } catch (error) {
      console.error("Error:", error);
    }
  };
  const closeModal = () => {
    setShowModal(false);
  };

  //Lấy thông tin máy in, hiện lấy 6 cái
  useEffect(() => {
    const fetchPrinterInfo = async () => {
      if (!user) return;

      setLoading(true);
      setError(null);
      try {
        const response = await fetch(
          `https://ssfe-be.vercel.app/api/printerInfo/all`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch printer info.");
        }
        const data = await response.json();
        setPrinterList(data.slice(0, 6));
      } catch (err) {
        console.error("Error fetching printers:", err);
        setError("Đã xảy ra lỗi khi tải thông tin máy in.");
      } finally {
        setLoading(false);
      }
    };

    fetchPrinterInfo();
  }, [user]);

  return (
    <div>
      {/* Thông báo toast */}
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      {/* Header và tin nhắn chờ */}
      <div className="flex justify-between items-center mb-4">
        <p className="ml-4 font-bold">Danh sách máy in</p>
        <button
          className="px-2 py-1 rounded-md text-xs bg-blue-800 font-medium text-white mr-3"
          onClick={(val) => setShowModal(val)}
        >
          Thêm máy in
        </button>
      </div>
      {loading && (
        <p className="mt-4 ml-4 text-center text-gray-500">
          Đang tải dữ liệu...
        </p>
      )}
      {error && <p className="mt-4 ml-4 text-center text-red-500">{error}</p>}

      {/* Dữ liệu chính */}
      {!loading && !error && (
        <>
          {/* Printers List */}
          <div className="p-4 m-6 h-2/3 border rounded-lg border-gray-300 shadow overflow-y-auto">
            <table className="table-auto w-full border-collapse border border-gray-300">
              <thead className="bg-gray-100">
                <tr>
                  <th className="border border-gray-300 px-4 py-2 text-left">
                    Tên máy in
                  </th>
                  <th className="border border-gray-300 px-4 py-2 text-left">
                    Status
                  </th>
                  <th className="border border-gray-300 px-4 py-2 text-left">
                    Brand và Model
                  </th>
                  <th className="border border-gray-300 px-4 py-2 text-left">
                    Mô tả máy in
                  </th>
                </tr>
              </thead>
              <tbody>
                {printerList.map((printer, index) => (
                  <tr key={index} className="even:bg-gray-50">
                    <td className="flex items-center py-2">
                      <img
                        src="/printer.png"
                        alt={printer.printerID}
                        className="w-12 h-12 mr-2"
                      />
                      <div className="flex flex-col">
                        <p className="font-semibold">{printer.printerID}</p>
                        <p className="text-xs text-gray-500">
                          {printer.location}
                        </p>
                      </div>
                    </td>
                    <td
                      id={printer._id}
                      className={`cursor-pointer border border-gray-300 px-4 py-2 ml-2 font-bold ${
                        printer.printerStatus === "On"
                          ? "bg-green-500 bg-opacity-25  text-green-800 hover:bg-green-600"
                          : "bg-red-500 bg-opacity-25 text-red-800 hover:bg-red-600"
                      }`}
                      onClick={updateStatus}
                    >
                      {printer.printerStatus === "On" ? "Khả dụng" : "Bảo trì"}
                    </td>
                    <td className="border border-gray-300 px-4 py-2">
                      {printer.brandName}-{printer.printerModel}
                    </td>
                    <td className="border border-gray-300 px-4 py-2">
                      {printer.printerDesc}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      {/* Modal thêm máy in */}
      {showModal && (
        <>
          <div className="fixed inset-0 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded shadow max-w-3xl w-11/12 md:w-3/4 lg:w-1/2 h-5/6 overflow-auto">
              <h2 className="text-md font-bold">Thêm máy in</h2>
              {/* Input field */}
              <form className="flex flex-col" onSubmit={handleSubmit}>
                <input
                  className="w-80 h-12 p-2 mb-4 rounded-lg border-customCyan border-2"
                  placeholder="Tên/ID máy in"
                  value={printerID}
                  onChange={(event) => setPrinterID(event.target.value)}
                  required
                />
                <input
                  className="w-80 h-12 p-2 mb-4 rounded-lg border-customCyan border-2"
                  placeholder="Nhà sản xuất"
                  value={brandName}
                  onChange={(event) => setBrandName(event.target.value)}
                />
                <input
                  className="w-80 h-12 p-2 mb-4 rounded-lg border-customCyan border-2"
                  placeholder="Phiên bản máy in"
                  value={printerModel}
                  onChange={(event) => setPrinterModel(event.target.value)}
                />
                <input
                  className="w-80 h-12 p-2 mb-4 rounded-lg border-customCyan border-2"
                  placeholder="Mô tả ngắn"
                  value={printerDesc}
                  onChange={(event) => setPrinterDesc(event.target.value)}
                />
                <input
                  className="w-80 h-12 p-2 mb-4 rounded-lg border-customCyan border-2"
                  placeholder="Vị trí máy in"
                  value={location}
                  onChange={(event) => setLocation(event.target.value)}
                  required
                />
                {/* Buttons */}
                <div className="mt-32 flex justify-end space-x-2">
                  <button
                    onClick={closeModal}
                    className="px-2 rounded-md py-1 text-xs bg-gray-200 font-medium text-black bg-opacity-50"
                  >
                    Trở lại
                  </button>
                  <button
                    type="submit"
                    className="px-2 py-1 rounded-md text-xs bg-blue-800 font-medium text-white"
                  >
                    Xác nhận
                  </button>
                </div>
              </form>
            </div>
          </div>
          <div className="fixed inset-0 bg-black opacity-50 z-40"></div>
        </>
      )}
    </div>
  );
};

export default ManagePrinter;
