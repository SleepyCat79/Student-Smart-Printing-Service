// File: Recharge.jsx
import React, { useState, useEffect, useContext } from "react";
import { FcDocument } from "react-icons/fc";
import { FaPlus } from "react-icons/fa";
import { AuthContext } from "../../AuthContext/AuthContext";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const API_BASE_URL = "https://ssfe-be.vercel.app";

const Recharge = () => {
  const { user } = useContext(AuthContext);
  const [history, setHistory] = useState([]);
  const [paperData, setPaperData] = useState({
    totalPapersRemaining: 0,
    papersPurchased: 0,
    papersUsed: 0,
  });
  const [rechargeAmount, setRechargeAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("momo");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [rechargeLoading, setRechargeLoading] = useState(false);

  // Fetch paper data and recharge history on component mount
  useEffect(() => {
    const fetchData = async () => {
      if (!user || !user.email) {
        setError("User is not authenticated.");
        setLoading(false);
        return;
      }

      try {
        // Fetch paper data
        const paperResponse = await fetch(
          `${API_BASE_URL}/api/paperStore/papers/${encodeURIComponent(
            user.email
          )}`
        );

        if (!paperResponse.ok) {
          const errorData = await paperResponse.json();
          throw new Error(errorData.message || "Failed to fetch paper data.");
        }

        const paperData = await paperResponse.json();
        setPaperData(paperData.paperStore);

        // Fetch recharge history
        const historyResponse = await fetch(
          `${API_BASE_URL}/api/paperStore/rechargeHistory/${encodeURIComponent(
            user.email
          )}`
        );

        if (!historyResponse.ok) {
          const errorData = await historyResponse.json();
          throw new Error(
            errorData.message || "Failed to fetch recharge history."
          );
        }

        const historyData = await historyResponse.json();
        setHistory(historyData.history);
      } catch (err) {
        console.error("Error fetching data:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  // Handle recharge action
  const handleRecharge = async () => {
    // Input validation
    if (!rechargeAmount || isNaN(rechargeAmount) || rechargeAmount <= 0) {
      toast.error("Please enter a valid positive number.");
      return;
    }

    setRechargeLoading(true);

    try {
      const response = await fetch(`${API_BASE_URL}/api/paperStore/recharge`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: user.email,
          rechargeAmount: Number(rechargeAmount),
          paymentMethod,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to recharge papers.");
      }

      const data = await response.json();

      // Update paper counts
      setPaperData(data.paperStore);

      // Update recharge history
      setHistory((prevHistory) => [data.rechargeHistory, ...prevHistory]);

      toast.success("Nạp giấy thành công");
      setRechargeAmount("");
      setPaymentMethod("momo");
    } catch (err) {
      console.error("Lỗi nạp thẻ:", err);
      toast.error(err.message);
    } finally {
      setRechargeLoading(false);
    }
  };

  const totalMoney = rechargeAmount ? rechargeAmount * 500 : 0;

  // Conditional rendering based on loading and error states
  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p className="text-gray-500">Loading...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p className="text-red-500">{error}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-100 p-8 space-y-8">
      <ToastContainer />
      {/* Recharge Card */}
      <div className="border-2 rounded-lg shadow-lg w-2/3 lg:w-1/3 h-64 bg-white flex flex-row">
        <div className="flex flex-col justify-center items-center p-4 border-r">
          <p className="text-sm font-medium text-gray-700">Giấy A4</p>
          <FcDocument size={120} className="my-4" />
          <p className="text-xs text-red-400 font-medium italic text-center">
            Lưu ý: 1 trang A3 = 2 trang A4
          </p>
        </div>
        <div className="flex flex-col justify-center p-4 space-y-4">
          <div>
            <p className="text-md font-bold text-customCyan">
              {paperData.totalPapersRemaining} trang
            </p>
            <p className="text-xs text-gray-400">Số giấy còn lại</p>
          </div>
          <div>
            <p className="text-md font-bold text-green-700">
              {paperData.papersPurchased} trang
            </p>
            <p className="text-xs text-gray-400">Số giấy đã nạp</p>
          </div>
          <div>
            <p className="text-md font-bold text-red-500">
              {paperData.papersUsed} trang
            </p>
            <p className="text-xs text-gray-400">Số giấy đã in</p>
          </div>
        </div>
      </div>

      {/* History and Recharge Form */}
      <div className="flex flex-col lg:flex-row w-full lg:w-3/4 bg-white rounded-lg shadow-lg p-6 space-y-6 lg:space-y-0 lg:space-x-6">
        {/* Recharge History */}
        <div className="w-full lg:w-2/3">
          <h2 className="text-lg font-bold mb-4">Lịch Sử Nạp Giấy</h2>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                  Ngày
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                  Số Lượng
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                  Phương Thức Thanh Toán
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                  Trạng Thái
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {history.length > 0 ? (
                history.map((item) => (
                  <tr key={item.id}>
                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">
                      {new Date(item.date).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">
                      {item.amount} trang
                    </td>
                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700 capitalize">
                      {item.paymentMethod}
                    </td>
                    <td className="px-4 py-2 whitespace-nowrap text-sm">
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          item.status === "Completed"
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan="5"
                    className="px-4 py-2 text-center text-sm text-gray-500"
                  >
                    Không có lịch sử nạp giấy
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Recharge Form */}
        <div className="w-full lg:w-1/3">
          <h2 className="text-lg font-bold mb-4">Nạp Giấy</h2>
          <div className="flex flex-col space-y-4">
            {/* Số Lượng Giấy Input */}
            <div>
              <label
                htmlFor="amount"
                className="block text-sm font-medium text-gray-700"
              >
                Số Lượng Giấy
              </label>
              <input
                type="number"
                id="amount"
                value={rechargeAmount}
                onChange={(e) => setRechargeAmount(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-customCyan focus:border-customCyan sm:text-sm"
                placeholder="Nhập số lượng giấy"
                min="1"
                required
              />
            </div>

            {/* Phương Thức Thanh Toán Select */}
            <div>
              <label
                htmlFor="paymentMethod"
                className="block text-sm font-medium text-gray-700"
              >
                Phương Thức Thanh Toán
              </label>
              <select
                id="paymentMethod"
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-customCyan focus:border-customCyan sm:text-sm"
                required
              >
                <option value="momo">Momo</option>
                <option value="bank">Ngân Hàng</option>
                <option value="cash">Tiền Mặt</option>
              </select>
            </div>

            {/* Tổng Tiền Cần Thanh Toán */}
            <div className="text-sm text-gray-600">
              Tổng tiền cần thanh toán:{" "}
              <span className="font-semibold text-gray-800">
                {totalMoney.toLocaleString()} VND
              </span>
            </div>

            {/* Recharge Button */}
            <button
              onClick={handleRecharge}
              disabled={rechargeLoading}
              className={`flex items-center justify-center px-4 py-2 bg-customCyan text-white text-sm font-medium rounded-md hover:bg-customCyan-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-customCyan ${
                rechargeLoading ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              <FaPlus className="mr-2" />
              {rechargeLoading ? "Nạp..." : "Nạp Giấy"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Recharge;
