import React, { useState, useRef, useEffect, useContext } from "react";
import "./PrintScreen.css";
import { AuthContext } from "../../AuthContext/AuthContext";
import { renderAsync } from "docx-preview";
import { Document, Page, pdfjs } from "react-pdf";
import * as FA from "react-icons/fa";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

// DisplayFileType Component
const DisplayFileType = ({ filetype }) => {
  switch (filetype.toUpperCase()) {
    case "PDF":
      return <img className="w-14 h-14" src="/pdf.png" alt="PDF Icon" />;
    case "DOC":
    case "DOCX":
      return <img className="w-14 h-14" src="/DOC.png" alt="DOC Icon" />;
    case "PPT":
    case "PPTX":
      return <img className="w-14 h-14" src="/ppt.png" alt="PPT Icon" />;
    case "XLS":
    case "XLSX":
      return <img className="w-14 h-14" src="/xls.png" alt="XLS Icon" />;
    default:
      return <FA.FaRegFile className="w-14 h-14" />;
  }
};

const PrintScreen = () => {
  const { user } = useContext(AuthContext);

  const [error, setError] = useState("");
  const [fileContent, setFileContent] = useState(null);
  const [docxArrayBuffer, setDocxArrayBuffer] = useState(null);
  const [selectedOrientation, setSelectedOrientation] = useState("Portrait");
  const [selectedPage, setSelectedPage] = useState("All");
  const [customPageInput, setCustomPageInput] = useState("");
  const [numPages, setNumPages] = useState(null);
  const [finalPage, setFinalPage] = useState(null);
  const [PrintedList, setPrintedList] = useState([]);
  const [selectedPaperSize, setSelectedPaperSize] = useState("A4");
  const [Printers, setPrinters] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showPrinterModal, setShowPrinterModal] = useState(false);
  const [selectedPrinter, setSelectedPrinter] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileURL, setFileURL] = useState(null);

  const viewerRef = useRef(null);
  const modalViewerRef = useRef(null);
  useEffect(() => {
    fetch("https://ssfe-be.vercel.app/api/printerInfo/all")
      .then((response) => response.json())
      .then((data) => setPrinters(data))
      .catch((error) => console.error("Error fetching printer data:", error));
  }, []);
  useEffect(() => {
    if (docxArrayBuffer && viewerRef.current) {
      const renderDocx = async () => {
        try {
          await renderAsync(docxArrayBuffer, viewerRef.current);

          setShowModal(true);
        } catch (err) {
          console.error("Error rendering document:", err);
          toast.error("Đã có lỗi xảy ra khi render tài liệu.");
          setFileContent(null);
        }
      };
      renderDocx();
    }

    if (docxArrayBuffer && modalViewerRef.current) {
      const renderDocxInModal = async () => {
        try {
          await renderAsync(docxArrayBuffer, modalViewerRef.current);
        } catch (err) {
          console.error("Error rendering document in modal:", err);
          toast.error("Đã có lỗi xảy ra khi render tài liệu trong modal.");
        }
      };
      renderDocxInModal();
    }
  }, [docxArrayBuffer]);

  const onDocumentLoadSuccess = ({ numPages }) => {
    setNumPages(numPages);
  };

  const handleFileChange = async (event) => {
    const selectedFile = event.target.files[0];
    setSelectedFile(selectedFile);
    if (selectedFile && selectedFile.type === "application/pdf") {
      const url = URL.createObjectURL(selectedFile);
      setFileURL(url);
    }
    if (selectedFile) {
      const fileName = selectedFile.name.toLowerCase();
      const fileType = selectedFile.type;

      if (fileType === "application/pdf" || fileName.endsWith(".pdf")) {
        setError("");
        const fileURL = URL.createObjectURL(selectedFile);
        setFileContent(
          <embed src={fileURL} type="application/pdf" className="w-full h-96" />
        );
        setDocxArrayBuffer(null);
        setShowModal(true);
      } else if (
        fileType ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        fileName.endsWith(".docx")
      ) {
        setError("");

        try {
          const arrayBuffer = await selectedFile.arrayBuffer();

          setFileContent(
            <div
              ref={viewerRef}
              className="border border-gray-300 p-4 h-96 overflow-auto"
            ></div>
          );

          setDocxArrayBuffer(arrayBuffer);
        } catch (err) {
          console.error("Error reading document:", err);
          toast.error("Đã có lỗi xảy ra khi đọc tài liệu.");
          setFileContent(null);
        }
      } else {
        toast.error("Vui lòng tải lên tệp PDF hoặc DOCX hợp lệ.");
        setFileContent(null);
        setDocxArrayBuffer(null);
      }
    }
  };

  const getFileType = (type, name) => {
    if (type === "application/pdf" || name.toLowerCase().endsWith(".pdf")) {
      return "PDF";
    } else if (
      type ===
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
      name.toLowerCase().endsWith(".docx")
    ) {
      return "DOCX";
    } else if (
      type.startsWith("application/vnd.ms-powerpoint") ||
      name.toLowerCase().endsWith(".pptx")
    ) {
      return "PPTX";
    } else if (
      type.startsWith("application/vnd.ms-excel") ||
      name.toLowerCase().endsWith(".xlsx")
    ) {
      return "XLSX";
    } else {
      return "FILE";
    }
  };

  const handlePrintConfirmation = () => {
    if (!user) {
      toast.error("Người dùng chưa được xác thực.");
      return;
    }

    let pagesToPrint = numPages;

    if (selectedPage === "Even") {
      pagesToPrint = Math.floor(numPages / 2);
    } else if (selectedPage === "Odd") {
      pagesToPrint = Math.ceil(numPages / 2);
    } else if (selectedPage === "Custom") {
      const customPages = customPageInput.split(",").reduce((acc, range) => {
        const [start, end] = range.split("-").map(Number);
        if (end) {
          return acc + (end - start + 1);
        }
        return acc + 1;
      }, 0);
      pagesToPrint = customPages;
    }

    const newPrintJob = {
      userEmail: user.email,
      name: selectedFile ? selectedFile.name : "",
      type: selectedFile
        ? getFileType(selectedFile.type, selectedFile.name)
        : "",
      printer: selectedPrinter ? selectedPrinter.printerID : "",
      paperSize: selectedPaperSize,
      orientation: selectedOrientation,
      numofpapers: pagesToPrint,
      numbers: 1,
    };

    setPrintedList([...PrintedList, newPrintJob]);

    toast.success("Danh sách in đã được cập nhật.");

    // Reset selections
    setShowPrinterModal(false);
    setSelectedPrinter(null);
    setSelectedOrientation("Portrait");
    setSelectedPage("All");
    setCustomPageInput("");
  };

  const decreaseNumber = (index) => {
    const updatedList = PrintedList.map((item, i) =>
      i === index && item.numbers > 1
        ? { ...item, numbers: item.numbers - 1 }
        : item
    );
    setPrintedList(updatedList);
  };

  const increaseNumber = (index) => {
    const updatedList = PrintedList.map((item, i) =>
      i === index ? { ...item, numbers: item.numbers + 1 } : item
    );
    setPrintedList(updatedList);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const closePrinterModal = () => {
    setShowPrinterModal(false);
    setShowModal(true);
  };

  const selectPrinter = (printer) => {
    setSelectedPrinter(printer);
  };

  const confirmSelection = () => {
    setShowModal(false);
    setShowPrinterModal(true);
  };

  // Add this function inside the PrintScreen component
  const deleteItem = (index) => {
    const updatedList = PrintedList.filter((_, i) => i !== index);
    setPrintedList(updatedList);
  };

  const handleUploadAllPrintJobs = async () => {
    if (!PrintedList.length) {
      toast.error("Lỗi hệ thống: Danh sách in trống.");
      return;
    }

    try {
      const uploadPromises = PrintedList.map((printJob) =>
        fetch("https://ssfe-be.vercel.app/api/printJobs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(printJob),
        })
      );

      const responses = await Promise.all(uploadPromises);
      const results = await Promise.all(responses.map((res) => res.json()));

      const failed = results.filter((result, index) => !responses[index].ok);

      if (failed.length === 0) {
        setPrintedList([]); // Clear the list after successful uploads
        toast.success("Tất cả tài liệu đã được in thành công!");
      } else {
        toast.warn(
          `Bạn không đủ giấy để in thêm ${failed.length} tài liệu. Vui lòng nạp thêm.`
        );
      }
    } catch (err) {
      console.error("Network error:", err);
      toast.error("Lỗi mạng.");
    }
  };
  const calculatePagesToPrint = () => {
    let pagesToPrint = numPages;

    if (selectedPage === "Even") {
      pagesToPrint = Math.floor(numPages / 2);
    } else if (selectedPage === "Odd") {
      pagesToPrint = Math.ceil(numPages / 2);
    } else if (selectedPage === "Custom") {
      const customPages = customPageInput.split(",").reduce((acc, range) => {
        const [start, end] = range.split("-").map(Number);
        if (end) {
          return acc + (end - start + 1);
        }
        return acc + 1;
      }, 0);
      pagesToPrint = customPages;
    }

    return pagesToPrint;
  };

  const pagesToPrint = calculatePagesToPrint();
  const totalPapersNeeded = PrintedList.reduce((total, item) => {
    const multiplier = item.paperSize === "A3" ? 2 : 1;
    return total + item.numofpapers * item.numbers * multiplier;
  }, 0);
  return (
    <div className="flex">
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      {/* Main Content */}
      <div className="w-full">
        <div>
          <p className="ml-4 font-bold">In theo cách của bạn</p>
        </div>
        <div>
          <label htmlFor="file-upload">
            <img
              className="w-1/2 ml-10 mt-10 cursor-pointer"
              src="/Uploading.png"
              alt="Upload"
            />
          </label>
          <input
            id="file-upload"
            type="file"
            accept=".pdf,.docx"
            className="hidden"
            onChange={handleFileChange}
          />
        </div>
        <div className="mt-10 ml-10">
          {error && <div className="text-red-500 mb-4">{error}</div>}
          {fileURL && (
            <Document
              file={fileURL}
              onLoadSuccess={onDocumentLoadSuccess}
              onLoadError={(error) => console.error("PDF load error:", error)}
            ></Document>
          )}
          {PrintedList.length > 0 && (
            <div className="flex flex-col" style={{ height: "400px" }}>
              <div className="flex-grow overflow-y-auto">
                <table className="min-w-full divide-y divide-gray-200 border">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                        Name
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                        Số trang
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                        Số lượng
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                        Máy in
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase"></th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {PrintedList.map((item, index) => (
                      <tr key={index}>
                        <td className="px-4 flex flex-row py-2 whitespace-nowrap text-sm text-gray-700">
                          <DisplayFileType filetype={item.type} />
                          <div className="flex flex-col ml-2 mt-2 ">
                            <p className="text-md font-medium">{item.name}</p>
                            <p className="text-sm font-light text-gray-500 mt-1">
                              {item.orientation}, {item.paperSize}
                            </p>
                          </div>
                        </td>
                        <td className="px-8 py-2 whitespace-nowrap text-sm text-gray-700">
                          {item.numofpapers}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">
                          <div className="flex items-center">
                            <button
                              onClick={() => decreaseNumber(index)}
                              className="px-2 py-1 rounded-l text-xl bg-gray-300"
                            >
                              -
                            </button>
                            <span className="px-4">{item.numbers}</span>
                            <button
                              onClick={() => increaseNumber(index)}
                              className="px-2 bg-gray-300 py-1 rounded-r text-xl"
                            >
                              +
                            </button>
                          </div>
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">
                          {item.printer}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-gray-700">
                          <button
                            onClick={() => deleteItem(index)}
                            className="text-2xl"
                          >
                            <FA.FaRegTrashAlt />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-4 flex justify-between items-center">
                <p className="font-bold text-lg">
                  Tổng giấy cần: {totalPapersNeeded}
                </p>
                <button
                  onClick={handleUploadAllPrintJobs}
                  className="px-8 py-4 bg-blue-800 text-white rounded-md font-medium"
                >
                  Confirm
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal */}
        {showModal && selectedFile && (
          <>
            <div className="fixed inset-0 flex items-center justify-center z-50">
              <div className="bg-white p-6 rounded shadow max-w-3xl w-11/12 md:w-3/4 lg:w-1/2 h-5/6 flex flex-col">
                <h2 className="text-md font-bold">Tạo lệnh in</h2>
                <h3 className="mb-4 text-xs">
                  Chọn máy in để thực hiện in{" "}
                  <span className="font-bold text-customCyan">
                    {selectedFile.name}
                  </span>
                </h3>
                {/* Printer List */}
                <div className="flex-grow overflow-y-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {Printers.filter(
                    (printer) => printer.printerStatus === "On"
                  ).map((printer, index) => (
                    <div
                      key={index}
                      className={`border p-4 flex flex-col items-center cursor-pointer rounded-lg ${
                        selectedPrinter === printer
                          ? "border-blue-800 border-2"
                          : "border-customCyan"
                      }`}
                      onClick={() => selectPrinter(printer)}
                    >
                      <img
                        src="/printer.png"
                        alt={printer.printerID}
                        className="w-16 h-16 mb-2"
                      />
                      <h3 className="font-semibold">{printer.printerID}</h3>
                      <p
                        className={`text-xs font-bold px-1 ${
                          printer.printerStatus === "On"
                            ? "bg-green-500 bg-opacity-25 text-green-800 "
                            : "bg-red-500 bg-opacity-25 text-red-800"
                        }`}
                      >
                        {printer.printerStatus === "On" ? "Khả thi" : "Bảo trì"}
                      </p>
                      <p className="text-xs text-gray-500 mt-2">
                        {printer.location}
                      </p>
                    </div>
                  ))}
                </div>
                {/* Buttons */}
                <div className="mt-4 flex justify-end space-x-2">
                  <button
                    onClick={closeModal}
                    className="px-2 rounded-md py-1 text-xs bg-gray-200 font-medium text-black bg-opacity-50"
                  >
                    Trở lại
                  </button>
                  <button
                    onClick={confirmSelection}
                    className="px-2 py-1 rounded-md text-xs bg-blue-800 font-medium text-white"
                  >
                    Xác nhận
                  </button>
                </div>
              </div>
            </div>
            <div
              className="fixed inset-0 bg-black opacity-50 z-40"
              onClick={closeModal}
            ></div>
          </>
        )}

        {/* Printer Modal */}
        {showPrinterModal && (
          <>
            <div className="fixed inset-0 flex items-center justify-center z-50 ">
              <div className="bg-white p-6 rounded shadow max-w-3xl w-11/12 md:w-3/4 lg:w-1/2 h-5/6 overflow-hidden">
                <h2 className="text-md font-bold">Tạo lệnh in</h2>

                {selectedPrinter && (
                  <div className="border text-sm px-2 flex flex-row items-center mb-2">
                    <img
                      src="/printer.png"
                      alt={selectedPrinter.printerID}
                      className="w-12 h-12 mb-2"
                    />
                    <div className="ml-4">
                      <div className="flex flex-row items-center">
                        <h3 className="font-semibold">
                          {selectedPrinter.printerID}
                        </h3>
                        <p
                          className={`text-xs font-bold px-1 ml-2 ${
                            selectedPrinter.printerStatus === "On"
                              ? "bg-green-500 bg-opacity-25 text-green-800 "
                              : "bg-red-500 bg-opacity-25 text-red-800"
                          }`}
                        >
                          {selectedPrinter.printerStatus === "On"
                            ? "Khả thi"
                            : "Bảo trì"}
                        </p>
                      </div>
                      <p className="text-xs text-gray-500">
                        {selectedPrinter.location}
                      </p>
                    </div>
                  </div>
                )}
                <div className="flex  md:flex-row ">
                  <div className="flex flex-col w-1/2 ">
                    <div className="mb-4 mr-2">
                      <label
                        htmlFor="paperSize"
                        className="  block  text-sm font-bold text-gray-700"
                      >
                        Kích thước giấy
                      </label>
                      <select
                        id="paperSize"
                        name="paperSize"
                        value={selectedPaperSize}
                        onChange={(e) => setSelectedPaperSize(e.target.value)}
                        className="mt-1 block w-full pl-3 pr-10 py-1 w-3/5 text-xs border border-gray-300 rounded-md shadow-lg focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      >
                        <option value="A4">A4</option>
                        <option value="A3">A3</option>
                      </select>
                    </div>
                    <div className="mb-4">
                      <span className="block text-sm font-bold text-gray-700">
                        Hướng giấy
                      </span>
                      <div className="mt-2 flex flex-col">
                        <label className="inline-flex items-center mr-6">
                          <input
                            type="radio"
                            className="form-radio h-4 w-4 accent-customCyan"
                            name="orientation"
                            value="Portrait"
                            checked={selectedOrientation === "Portrait"}
                            onChange={(e) =>
                              setSelectedOrientation(e.target.value)
                            }
                          />
                          <span className="ml-2 text-sm">Portrait</span>
                        </label>
                        <label className="inline-flex items-center mt-2">
                          <input
                            type="radio"
                            className="form-radio h-4 w-4 accent-customCyan"
                            name="orientation"
                            value="Landscape"
                            checked={selectedOrientation === "Landscape"}
                            onChange={(e) =>
                              setSelectedOrientation(e.target.value)
                            }
                          />
                          <span className="ml-2 text-sm">Landscape</span>
                        </label>
                      </div>
                    </div>
                    <div className="mb-4 ">
                      <span className="block text-sm font-bold text-gray-700">
                        Số trang
                      </span>
                      <div className="mt-2 flex flex-col space-y-2">
                        <label className="inline-flex items-center mr-6">
                          <input
                            type="radio"
                            className="form-radio h-4 w-4 accent-customCyan"
                            name="page"
                            value="All"
                            checked={selectedPage === "All"}
                            onChange={(e) => setSelectedPage(e.target.value)}
                          />
                          <span className="ml-2 text-sm">Tất cả</span>
                        </label>
                        <label className="inline-flex items-center mr-6">
                          <input
                            type="radio"
                            className="form-radio h-4 w-4 accent-customCyan"
                            name="page"
                            value="Even"
                            checked={selectedPage === "Even"}
                            onChange={(e) => setSelectedPage(e.target.value)}
                          />
                          <span className="ml-2 text-sm">Chỉ trang chẵn</span>
                        </label>
                        <label className="inline-flex items-center mr-6">
                          <input
                            type="radio"
                            className="form-radio h-4 w-4 accent-customCyan"
                            name="page"
                            value="Odd"
                            checked={selectedPage === "Odd"}
                            onChange={(e) => setSelectedPage(e.target.value)}
                          />
                          <span className="ml-2 text-sm">Chỉ trang lẻ</span>
                        </label>
                        <div className="flex flex-row">
                          <label className="inline-flex items-center">
                            <input
                              type="radio"
                              className="form-radio h-4 w-4 accent-customCyan"
                              name="page"
                              value="Custom"
                              checked={selectedPage === "Custom"}
                              onChange={(e) => setSelectedPage(e.target.value)}
                            />
                            <span className="ml-2"></span>
                          </label>
                          <div className="mt-2">
                            <input
                              type="text"
                              className={`form-input text-xs  pl-1 pr-1 py-1 border border-gray-300 rounded-md shadow-sm ${
                                selectedPage !== "Custom"
                                  ? "bg-gray-200 cursor-not-allowed"
                                  : ""
                              }`}
                              placeholder="Ví dụ: 1,3,5-7"
                              value={customPageInput}
                              onChange={(e) =>
                                setCustomPageInput(e.target.value)
                              }
                              disabled={selectedPage !== "Custom"}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className=" md:w-1/2">
                    {docxArrayBuffer && (
                      <div ref={modalViewerRef} className=""></div>
                    )}
                    {fileContent && fileContent.type === "embed" && fileContent}
                  </div>
                </div>
                <div>
                  <div className="border border-1 mt-2 border-gray-500"></div>
                  <div className="flex flex-row justify-between mt-4">
                    <p className="font-medium text-sm">Giá in </p>
                    <p className="font-bold text-lg mr-4">
                      {selectedPaperSize === "A3"
                        ? pagesToPrint * 2
                        : pagesToPrint}{" "}
                      trang
                    </p>
                  </div>
                </div>
                <div className="mt-8 flex justify-end space-x-2">
                  <button
                    onClick={closePrinterModal}
                    className="px-2 rounded-md py-1 text-xs bg-gray-200 font-medium text-black bg-opacity-50"
                  >
                    Trở lại
                  </button>
                  <button
                    onClick={handlePrintConfirmation}
                    className="px-2 py-1 rounded-md text-xs bg-blue-800 font-medium text-white"
                  >
                    Xác nhận
                  </button>
                </div>
              </div>
            </div>
            <div
              className="fixed inset-0 bg-black opacity-50 z-40"
              onClick={closePrinterModal}
            ></div>
          </>
        )}
      </div>

      {/* Printers List */}
      {/* <div className="p-4 w-72 m-6 h-2/3  border rounded-lg border-gray-300 shadow overflow-y-auto">
        <h2 className="text-xs font-medium mb-4">Danh sách Máy in</h2>
        <ul className="space-y-4">
          {Printers.map((printer, index) => (
            <li key={index} className="flex items-center py-2">
              <img
                src="/printer.png"
                alt={printer.name}
                className="w-12 h-12 mr-2"
              />
              <div>
                <div className="flex flex-row">
                  <p className="font-semibold">{printer.name}</p>
                  <p
                    className={`text-xxs ml-2 font-bold h-2 ${
                      printer.status === "Active"
                        ? "bg-green-500 bg-opacity-25  text-green-800 "
                        : "bg-red-500 bg-opacity-25 text-red-800"
                    }`}
                  >
                    {printer.status === "Active" ? "Khả thi" : "Bảo trì"}
                  </p>
                </div>
                <p className="text-xs text-gray-500">{printer.location}</p>
              </div>
            </li>
          ))}
        </ul>
      </div> */}
    </div>
  );
};

export default PrintScreen;
