// File: SignIn.jsx
import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../AuthContext/AuthContext"; // Adjust the path if necessary

const SignIn = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    login(email, password);
    navigate("/", { replace: true });
  };

  return (
    <div className="flex flex-row overflow-hidden h-screen">
      {/* Left Div */}
      <div
        style={{
          backgroundImage: "url('/background.png')",
          backgroundSize: "cover",
          width: "50vw",
          height: "100vh",
        }}
      >
        <div className="flex flex-row items-center p-4">
          <img className="h-24 w-24" src="./logo.png" alt="Logo" />
          <div className="flex flex-col text-customBlue font-bold">
            <p>TRƯỜNG ĐẠI HỌC BÁCH KHOA</p>
            <p className="text-xl">Student Smart Printing Service</p>
          </div>
        </div>
      </div>

      {/* Right Div */}
      <div
        className="flex items-center justify-center bg-white"
        style={{
          width: "50vw",
          height: "100vh",
        }}
      >
        <div className="text-center">
          <p className="mb-4 text-over font-bold">
            <span className="text-customCyan">SS</span>
            <span className="text-customBlue">PS</span>
          </p>
          <p className="mb-4 text-xl font-bold">
            <span className="text-customCyan">Chào mừng</span>
            <span className="text-customBlue"> trở lại,</span>
          </p>
          <form className="flex flex-col" onSubmit={handleSubmit}>
            <input
              className="w-80 h-12 p-2 mb-4 rounded-lg border-customCyan border-2"
              type="email"
              placeholder="Email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
            />
            <input
              className="w-80 h-12 p-2 mb-4 rounded-lg border-customCyan border-2"
              type="password"
              placeholder="Password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              required
            />
            <button
              type="submit"
              className="w-80 h-12 bg-customCyan text-white rounded flex items-center justify-center font-bold"
            >
              Đăng nhập
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
