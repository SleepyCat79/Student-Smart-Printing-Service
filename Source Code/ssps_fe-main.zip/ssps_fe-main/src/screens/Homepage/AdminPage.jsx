import React, { useState, useEffect, useContext } from "react";
import * as FA from "react-icons/fa";
import { AuthContext } from "../../AuthContext/AuthContext";

const AdminPage = () => {
  const { user } = useContext(AuthContext);
  const [printJobs, setPrintJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [printerList, setPrinterList] = useState([]);

  useEffect(() => {
    const fetchPrinterInfo = async () => {
      if (!user) return;

      setLoading(true);
      setError(null);
      try {
        const response = await fetch(
          `https://ssfe-be.vercel.app/api/printerInfo/all`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch printer info.");
        }
        const data = await response.json();
        setPrinterList(data.slice(0, 6));
      } catch (err) {
        console.error("Error fetching printers:", err);
        setError("Đã xảy ra lỗi khi tải thông tin máy in.");
      } finally {
        setLoading(false);
      }
    };

    fetchPrinterInfo();
  }, [user]);

  const DisplayFileType = ({ filetype }) => {
    switch (filetype) {
      case "PDF":
        return <img className="w-10 h-10" src="/pdf.png" alt="PDF Icon" />;
      case "DOC":
        return <img className="w-10 h-10" src="/DOC.png" alt="DOC Icon" />;
      case "PPT":
        return <img className="w-10 h-10" src="/ppt.png" alt="PPT Icon" />;
      case "XLS":
        return <img className="w-10 h-10" src="/xls.png" alt="XLS Icon" />;
      default:
        return <FA.FaRegFile />;
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case "Success":
        return "text-green-500";
      case "Error":
        return "text-red-500";
      default:
        return "";
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case "Success":
        return "Thành công";
      case "Error":
        return "Lỗi";
      default:
        return status;
    }
  };

  useEffect(() => {
    const fetchPrintJobs = async () => {
      if (!user) return;

      setLoading(true);
      setError(null);
      try {
        const response = await fetch(
          `https://ssfe-be.vercel.app/api/printJobs/all`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch print jobs.");
        }
        const data = await response.json();
        setPrintJobs(data.slice(0, 6));
      } catch (err) {
        console.error("Error fetching print jobs:", err);
        setError("Đã xảy ra lỗi khi tải lịch sử in.");
      } finally {
        setLoading(false);
      }
    };

    fetchPrintJobs();
  }, [user]);

  return (
    <div>
      <div>
        <p className="ml-4 font-bold">Lần in gần nhất</p>
      </div>

      {loading && (
        <p className="mt-4 ml-4 text-center text-gray-500">
          Đang tải dữ liệu...
        </p>
      )}
      {error && <p className="mt-4 ml-4 text-center text-red-500">{error}</p>}

      {!loading && !error && (
        <div className="flex">
          <table className="min-w-1/2 divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Người in
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Loại tệp
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tên tài liệu
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Số trang
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Loại
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Trạng thái
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Số bản in
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {printJobs.map((print) => (
                <tr key={print._id} className="hover:bg-gray-100 font-bold">
                  <td className="px-6 py-4 whitespace-nowrap">
                    {print.userEmail}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <DisplayFileType filetype={print.type} />
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {print.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.numofpapers}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.orientation}, {print.paperSize}
                  </td>
                  <td
                    className={`px-6 py-4 whitespace-nowrap text-sm ${getStatusClass(
                      print.status
                    )}`}
                  >
                    {getStatusText(print.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.numbers}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {printJobs.length === 0 && (
            <p className="mt-4 text-center text-gray-500">
              Không tìm thấy bản ghi nào.
            </p>
          )}
          {/* Printers List */}
          {/* <div className="p-4 w-72 m-6 h-2/3  border rounded-lg border-gray-300 shadow overflow-y-auto">
            <h2 className="text-xs font-medium mb-4">Danh sách Máy in</h2>
            <ul className="space-y-4">
              {printerList.map((printer, index) => (
                <li key={index} className="flex items-center py-2">
                  <img
                    src="/printer.png"
                    alt={printer.printerID}
                    className="w-12 h-12 mr-2"
                  />
                  <div>
                    <div className="flex flex-row">
                      <p className="font-semibold">{printer.printerID}</p>
                      <p
                        className={`text-xxs ml-2 font-bold h-2 ${
                          printer.printerStatus === "On"
                            ? "bg-green-500 bg-opacity-25  text-green-800 "
                            : "bg-red-500 bg-opacity-25 text-red-800"
                        }`}
                      >
                        {printer.printerStatus === "On"
                          ? "Khả dụng"
                          : "Bảo trì"}
                      </p>
                    </div>
                    <p className="text-xs text-gray-500">{printer.location}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div> */}
        </div>
      )}
    </div>
  );
};

export default AdminPage;
