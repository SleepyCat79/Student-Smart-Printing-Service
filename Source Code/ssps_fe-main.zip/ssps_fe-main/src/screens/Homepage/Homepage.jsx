import React, { useState, useEffect, useContext } from "react";
import * as FA from "react-icons/fa";
import { AuthContext } from "../../AuthContext/AuthContext";

const Homepage = () => {
  const { user } = useContext(AuthContext);
  const [printJobs, setPrintJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const DisplayFileType = ({ filetype }) => {
    switch (filetype) {
      case "PDF":
        return <img className="w-10 h-10" src="/pdf.png" alt="PDF Icon" />;
      case "DOC":
        return <img className="w-10 h-10" src="/DOC.png" alt="DOC Icon" />;
      case "PPT":
        return <img className="w-10 h-10" src="/ppt.png" alt="PPT Icon" />;
      case "XLS":
        return <img className="w-10 h-10" src="/xls.png" alt="XLS Icon" />;
      default:
        return <FA.FaRegFile />;
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case "Success":
        return "text-green-500";
      case "Error":
        return "text-red-500";
      default:
        return "";
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case "Success":
        return "Thành công";
      case "Error":
        return "Lỗi";
      default:
        return status;
    }
  };

  useEffect(() => {
    const fetchPrintJobs = async () => {
      if (!user) return;

      setLoading(true);
      setError(null);
      try {
        const response = await fetch(
          `https://ssfe-be.vercel.app/api/printJobs/${user.email}`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch print jobs.");
        }
        const data = await response.json();
        setPrintJobs(data.slice(0, 6));
      } catch (err) {
        console.error("Error fetching print jobs:", err);
        setError("Đã xảy ra lỗi khi tải lịch sử in.");
      } finally {
        setLoading(false);
      }
    };

    fetchPrintJobs();
  }, [user]);

  return (
    <div>
      <div>
        <p className="ml-4 font-bold">Lần in gần nhất</p>
      </div>

      {loading && (
        <p className="mt-4 ml-4 text-center text-gray-500">
          Đang tải dữ liệu...
        </p>
      )}
      {error && <p className="mt-4 ml-4 text-center text-red-500">{error}</p>}

      {!loading && !error && (
        <div>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Loại tệp
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tên tài liệu
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Số trang
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Loại
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Trạng thái
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Số bản in
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {printJobs.map((print) => (
                <tr key={print._id} className="hover:bg-gray-100 font-bold">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <DisplayFileType filetype={print.type} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.numofpapers}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.orientation}, {print.paperSize}
                  </td>
                  <td
                    className={`px-6 py-4 whitespace-nowrap text-sm ${getStatusClass(
                      print.status
                    )}`}
                  >
                    {getStatusText(print.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.numbers}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {printJobs.length === 0 && (
            <p className="mt-4 text-center text-gray-500">
              Không tìm thấy bản ghi nào.
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default Homepage;
