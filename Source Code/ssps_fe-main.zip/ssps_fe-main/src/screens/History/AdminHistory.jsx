import React, { useState, useRef, useEffect, useContext } from "react";
import * as FA from "react-icons/fa";
import { CiFilter } from "react-icons/ci";
import { AuthContext } from "../../AuthContext/AuthContext";
import moment from "moment/moment";

const ITEMS_PER_PAGE = 6;

const AdminHistory = () => {
  const { user } = useContext(AuthContext);
  const [printJobs, setPrintJobs] = useState([]);
  const [filters, setFilters] = useState({
    Filetype: "All",
    status: "All",
    PaperType: "All",
    PrintDate: "",
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const filterRef = useRef();

  const DisplayFileType = ({ filetype }) => {
    switch (filetype) {
      case "PDF":
        return <img className="w-10 h-10" src="/pdf.png" alt="PDF Icon" />;
      case "DOC":
        return <img className="w-10 h-10" src="/DOC.png" alt="DOC Icon" />;
      case "PPT":
        return <img className="w-10 h-10" src="/ppt.png" alt="PPT Icon" />;
      case "XLS":
        return <img className="w-10 h-10" src="/xls.png" alt="XLS Icon" />;
      default:
        return <FA.FaRegFile />;
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case "Success":
        return "text-green-500";
      case "Error":
        return "text-red-500";
      default:
        return "";
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case "Success":
        return "Thành công";
      case "Error":
        return "Lỗi";
      default:
        return status;
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const filteredPrints = printJobs.filter((print) => {
    const matchesSearch = searchQuery
      ? print.name.toLowerCase().includes(searchQuery.toLowerCase())
      : true;

    const matchesFiletype =
      filters.Filetype === "All" ||
      print.type?.toUpperCase() === filters.Filetype.toUpperCase();

    const matchesStatus =
      filters.status === "All" || print.status === filters.status;

    const matchesPaperType =
      filters.PaperType === "All" || print.paperSize === filters.PaperType;

    const matchesPrintDate =
      !filters.PrintDate ||
      moment(print.createdAt).isSame(moment(filters.PrintDate), "day");

    return (
      matchesSearch &&
      matchesFiletype &&
      matchesStatus &&
      matchesPaperType &&
      matchesPrintDate
    );
  });

  const handleClickOutside = (event) => {
    if (filterRef.current && !filterRef.current.contains(event.target)) {
      setShowFilters(false);
    }
  };

  useEffect(() => {
    if (showFilters) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showFilters]);

  useEffect(() => {
    const fetchPrintJobs = async () => {
      if (!user) return;

      setLoading(true);
      setError(null);
      try {
        const response = await fetch(
          `https://ssfe-be.vercel.app/api/printJobs/all`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch print jobs.");
        }
        const data = await response.json();
        setPrintJobs(data);
      } catch (err) {
        console.error("Error fetching print jobs:", err);
        setError("Đã xảy ra lỗi khi tải lịch sử in.");
      } finally {
        setLoading(false);
      }
    };

    fetchPrintJobs();
  }, [user]);

  // Pagination logic
  const totalPages = Math.ceil(filteredPrints.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const currentPrints = filteredPrints.slice(startIndex, endIndex);

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <div className="relative">
      <div className="flex justify-between items-center mb-4">
        <p className="ml-4 text-sm font-bold">Lịch sử in toàn hệ thống</p>

        <div className="flex items-center space-x-4 mr-16">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search..."
              className="py-2 pl-2 pr-56 placeholder:text-customCyan bg-customPink border-none text-customCyan rounded-lg focus:outline-none focus:ring-0"
            />
            <FA.FaSearch className="absolute right-4 top-1/2 transform -translate-y-1/2 text-customCyan" />
          </div>

          <div className="relative">
            <CiFilter
              className="mr-4 cursor-pointer"
              size={24}
              onClick={() => setShowFilters(!showFilters)}
            />
            {showFilters && (
              <div
                ref={filterRef}
                className="fixed right-4 w-60 bg-white border border-gray-300 rounded-md shadow-lg p-4 z-10"
              >
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Loại tệp
                  </label>
                  <select
                    name="Filetype"
                    value={filters.Filetype}
                    onChange={handleFilterChange}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  >
                    <option>All</option>
                    <option>PDF</option>
                    <option>DOC</option>
                    <option>PPT</option>
                    <option>XLS</option>
                  </select>
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Trạng thái
                  </label>
                  <select
                    name="status"
                    value={filters.status}
                    onChange={handleFilterChange}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  >
                    <option value="All">All</option>
                    <option value="Success">Thành công</option>
                    <option value="Error">Lỗi</option>
                  </select>
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Loại giấy
                  </label>
                  <select
                    name="PaperType"
                    value={filters.PaperType}
                    onChange={handleFilterChange}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  >
                    <option>All</option>
                    <option>A4</option>
                    <option>A3</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Ngày in
                  </label>
                  <input
                    name="PrintDate"
                    type="date"
                    value={filters.PrintDate}
                    onChange={handleFilterChange}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-[#E9E9ED] border-gray-300 focus:outline-none sm:text-sm rounded-md"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Loading and Error States */}
      {loading && (
        <p className="mt-4 ml-4 text-center text-gray-500">
          Đang tải dữ liệu...
        </p>
      )}
      {error && <p className="mt-4 ml-4 text-center text-red-500">{error}</p>}

      {/* Table */}
      {!loading && !error && (
        <div className="mt-4 ml-4 mr-4">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Người in
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Loại tệp
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tên tài liệu
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Số trang
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Loại
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Trạng thái và thời điểm in
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Số bản in
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {currentPrints.map((print) => (
                <tr key={print._id} className="hover:bg-gray-100">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.userEmail}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <DisplayFileType filetype={print.type} />
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {print.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.numofpapers}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.orientation}, {print.paperSize}
                  </td>
                  <td
                    className={`px-6 py-4 text-sm ${getStatusClass(
                      print.status
                    )}`}
                  >
                    {getStatusText(print.status)} vào{" "}
                    {moment(print.createdAt).format("DD-MM-YYYY HH:mm")}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {print.numbers}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredPrints.length === 0 && (
            <p className="mt-4 text-center text-gray-500">
              Không tìm thấy bản ghi nào.
            </p>
          )}
        </div>
      )}

      {/* Pagination Controls */}
      {!loading && !error && totalPages > 1 && (
        <div className="flex justify-center mt-4">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="px-4 py-2 mx-1 bg-gray-200 rounded disabled:opacity-50"
          >
            Previous
          </button>
          {Array.from({ length: totalPages }, (_, index) => (
            <button
              key={index + 1}
              onClick={() => handlePageChange(index + 1)}
              className={`px-4 py-2 mx-1 ${
                currentPage === index + 1
                  ? "bg-blue-500 text-white"
                  : "bg-gray-200"
              } rounded`}
            >
              {index + 1}
            </button>
          ))}
          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="px-4 py-2 mx-1 bg-gray-200 rounded disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default AdminHistory;
