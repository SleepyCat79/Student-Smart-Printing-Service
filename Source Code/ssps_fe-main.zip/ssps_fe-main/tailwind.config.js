/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    fontSize: {
      xxs: ".6rem",
      over: "4rem",
    },
    extend: {
      colors: {
        customBlue: "#030391",
        customCyan: "#1488D8",
        customPink: "#F5F3FF",
      },
    },
  },
  plugins: [],
};
